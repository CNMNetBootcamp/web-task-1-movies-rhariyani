﻿using System;
using Microsoft.AspNetCore.Mvc;

namespace Mvcmovie.Models.MvcMovie.Models
{
    public class Movie
    {
        public int? Id { get; internal set; }

        public DateTime ReleaseDate { get; internal set; }
        public string Title { get; internal set; }
        public string Genre { get; internal set; }
        public decimal Price { get; internal set; }
        public string Rating { get; set; }
    }
       
    

}