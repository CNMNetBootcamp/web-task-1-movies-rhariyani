﻿using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc.Rendering;
using MvcMovie.Models;

namespace Mvcmovie.Controllers
{
    public class MovieGenreViewModel
    {
        public SelectList Genres { get; set; }
        public List<Movie> Movies { get; set; }
        public string MovieGenre { get; set; }
        public string SearchString { get; set; }
    }
}