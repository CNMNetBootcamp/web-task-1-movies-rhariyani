﻿using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc.Rendering;
using Mvcmovie.Models.MvcMovie.Models;

namespace Mvcmovie.Controllers
{
    internal class MovieGenreViewModel
    {
        public SelectList Genres { get; set; }
        public List<Movie> Movies { get; set; }

        public static implicit operator MovieGenreViewModel(MovieGenreViewModel v)
        {
            throw new NotImplementedException();
        }
    }
}