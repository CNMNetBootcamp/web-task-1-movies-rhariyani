﻿using Microsoft.EntityFrameworkCore;
using MvcMovie.Models;

namespace Mvcmovie.Models
{

    namespace MvcMovie.Models
    {
        public class MvcMovieContext : DbContext
        {
            public MvcMovieContext(DbContextOptions<MvcMovieContext> options)
                : base(options)
            {
            }

            public DbSet<Movie> Movie { get; set; }
        }
    }
}