﻿using System;
using System.Collections.Generic;
[System.ComponentModel.DataAnnotations.DataType(System.ComponentModel.DataAnnotations.DataType.Date)]
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using MvcMovie.Models;

namespace Mvcmovie.Models
{
   
    namespace MvcMovie.Models
    {
        public class MvcMovieContext : DbContext
        {
            public MvcMovieContext(DbContextOptions<MvcMovieContext> options)
                : base(options)
            {
            }

            public DbSet<MvcMovie.Models.Movie> Movie { get; set; }
        }

        public class Movie
        {
            public int Id { get; set; }
            public string Title { get; set; }
            public DateTime ReleaseDate { get; set; }
            public string Genre { get; set; }
            public decimal Price { get; set; }
            public static object ID { get; internal set; }
        }
    }
}